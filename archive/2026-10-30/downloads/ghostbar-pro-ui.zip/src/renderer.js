let keyVisible = false;

function $(id){ return document.getElementById(id); }

function setMessage(text, type){
  const box = $('messageBox');
  box.textContent = text;
  box.className = `message-box ${type}`;
}

function updateApiStatus(){
  const hasKey = $('apiKeyInput').value.trim().length > 0;
  $('apiValue').textContent = hasKey ? 'Connected' : 'Not Connected';
  $('apiDot').className = hasKey ? 'dot on' : 'dot off';
}

function setActivity(items, ok=false){
  $('activityList').innerHTML = items.map(item => `
    <div class="activity-item">
      <span class="check ${ok ? 'ok' : 'muted'}">${ok ? '✓' : '•'}</span>
      <span>${item}</span>
    </div>
  `).join('');
}

function startGhostBar(){
  $('heroBanner').textContent = 'GhostBar starting...';
  $('heroBanner').className = 'hero-banner active';
  $('topStatus').textContent = 'Running';
  $('topStatus').className = 'status-pill active';
  $('runningSubtext').textContent = 'Startup flow is ready.';
  setActivity([
    'Start command received',
    'Waiting for your proxy wiring',
    $('apiKeyInput').value.trim() ? 'Gemini key detected' : 'No Gemini key saved yet'
  ], true);
  window.ghostbarAPI.start();
}

function stopGhostBar(){
  $('heroBanner').textContent = 'GhostBar stopped';
  $('heroBanner').className = 'hero-banner waiting';
  $('topStatus').textContent = 'Waiting';
  $('topStatus').className = 'status-pill';
  $('runningSubtext').textContent = 'Ready for your startup flow.';
  setActivity([
    'Stop command received',
    'Services marked as stopped',
    'Ready for next launch'
  ], false);
  window.ghostbarAPI.stop();
}

window.addEventListener('DOMContentLoaded', () => {
  $('pasteBtn').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) $('apiKeyInput').value = text.trim();
      updateApiStatus();
    } catch {
      setMessage('Clipboard access is blocked. Paste manually.', 'error');
    }
  });

  $('showBtn').addEventListener('click', () => {
    keyVisible = !keyVisible;
    $('apiKeyInput').type = keyVisible ? 'text' : 'password';
    $('showBtn').textContent = keyVisible ? 'Hide' : 'Show';
  });

  $('testBtn').addEventListener('click', () => {
    const value = $('apiKeyInput').value.trim();
    updateApiStatus();
    if (!value) {
      setMessage('Enter an API key first.', 'error');
    } else if (!value.startsWith('AIza')) {
      setMessage('Key format looks unusual. Expected it to start with AIza.', 'error');
    } else {
      setMessage('Key format looks valid.', 'success');
    }
  });

  $('saveBtn').addEventListener('click', () => {
    updateApiStatus();
    setMessage($('apiKeyInput').value.trim() ? 'API key saved successfully.' : 'Saved an empty value.', 'success');
  });

  $('startBtn').addEventListener('click', startGhostBar);
  $('stopBtn').addEventListener('click', stopGhostBar);
  $('refreshUiBtn').addEventListener('click', () => {
    updateApiStatus();
    setMessage('UI refreshed.', 'success');
  });

  $('apiKeyInput').addEventListener('input', updateApiStatus);
  updateApiStatus();
});
