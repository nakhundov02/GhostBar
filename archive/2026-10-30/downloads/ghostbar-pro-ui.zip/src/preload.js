const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('ghostbarAPI', {
  start: () => console.log('Wire your start logic here'),
  stop: () => console.log('Wire your stop logic here')
});
